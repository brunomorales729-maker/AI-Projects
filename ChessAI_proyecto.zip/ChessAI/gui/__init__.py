"""Graphical chess interface."""
